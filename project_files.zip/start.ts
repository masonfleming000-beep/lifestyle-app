import type { APIRoute } from "astro";
import crypto from "node:crypto";

export const prerender = false;

type OAuthState = {
  state: string;
  mobile?: boolean;
};

function encodeState(payload: OAuthState): string {
  return Buffer.from(JSON.stringify(payload), "utf8").toString("base64url");
}

function normalizeBaseUrl(value: string | undefined): string {
  return String(value || "").trim().replace(/\/+$/, "");
}

function getGoogleRedirectUri(): string {
  const explicitRedirect =
    import.meta.env.GOOGLE_REDIRECT_URI ||
    import.meta.env.GOOGLE_REDIRECT_URL;

  if (explicitRedirect) {
    return String(explicitRedirect).trim();
  }

  const baseUrl = normalizeBaseUrl(
    import.meta.env.APP_URL || import.meta.env.PUBLIC_APP_URL
  );

  if (!baseUrl) {
    return "";
  }

  return `${baseUrl}/api/auth/google/callback`;
}

export const GET: APIRoute = async ({ url, cookies, redirect }) => {
  const clientId =
    import.meta.env.GOOGLE_CLIENT_ID ||
    import.meta.env.PUBLIC_GOOGLE_CLIENT_ID;

  const redirectUri = getGoogleRedirectUri();

  if (!clientId || !redirectUri) {
    return new Response("Google OAuth is not configured.", { status: 500 });
  }

  const mobile = url.searchParams.get("mobile") === "true";
  const state = crypto.randomUUID();

  cookies.set("google_oauth_state", state, {
    path: "/",
    httpOnly: true,
    sameSite: "lax",
    secure: import.meta.env.PROD,
    maxAge: 60 * 10,
  });

  const encodedState = encodeState({
    state,
    mobile,
  });

  const googleUrl = new URL("https://accounts.google.com/o/oauth2/v2/auth");
  googleUrl.searchParams.set("client_id", clientId);
  googleUrl.searchParams.set("redirect_uri", redirectUri);
  googleUrl.searchParams.set("response_type", "code");
  googleUrl.searchParams.set("scope", "openid email profile");
  googleUrl.searchParams.set("state", encodedState);
  googleUrl.searchParams.set("prompt", "select_account");
  googleUrl.searchParams.set("access_type", "online");

  return redirect(googleUrl.toString(), 302);
};